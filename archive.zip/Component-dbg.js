sap.ui.define(['sap/suite/ui/generic/template/lib/AppComponent'], function(AppComponent) {
    return AppComponent.extend('z_soitems_rept.Component', {
        metadata: {
            manifest: 'json'
        }
    });
});
